#include "board.hpp"

Board::~Board() {}
